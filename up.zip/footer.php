<footer id="mastfoot" class="mastfoot dark-bg">

<section class="inner-section foot-top">
	<div class="container">
		<div class="row">
				<article class="col-md-12 text-center foot-logos">
				    	<img alt="APPLES INC." title="APPLES INC." class="foot-badge" src="images/foot-badge.png"/><br/>
					<p class="credits">ArkiPrdkxnz - APPLES INC.<br/>Copyright &copy; 2015</p>
				</article>
		</div>
	</div>
</section>


</footer>



</section>




<!-- Core JS Libraries -->
<script src="bootstrap/js/jquery.js" type="text/javascript"></script>
<script src="javascripts/jquery.easing.1.3.js" type="text/javascript"></script>
<script src="bootstrap/js/bootstrap.js" ></script> 
<!-- JS Plugins -->
<script src="javascripts/pace.min.js"></script>
<script src="javascripts/retina.js" ></script> 
<script src="javascripts/device.min.js"></script>
<script src="javascripts/classie.js" ></script> 
<script src="javascripts/slidingmenu.js" ></script> 
<script src="javascripts/jquery.touchSwipe.js"></script>
<script src="javascripts/waypoints.min.js" ></script> 
<script src="javascripts/smooth-scroll.js" ></script> 
<script src="javascripts/prettyPhoto.js" ></script> 
<script src="javascripts/flexslider.js" ></script> 
<script src="javascripts/jquery.tweet.js"></script>
<script src="javascripts/owl.carousel.js"></script>
<script src="javascripts/jquery.mixitup.js"></script>
<script src="javascripts/jquery.sudoSlider.js"></script>
<script src="javascripts/sudoslider-touch-init.js"></script>
<script src="javascripts/venobox.min.js"></script>
<script src="javascripts/jquery.appear.js"></script>
<script src="javascripts/nova-text-rotator.js" ></script> 
<script src="javascripts/jquery.parallax.min.js"></script>
<!-- JS Custom Codes --> 
<script src="javascripts/portfolio.js" ></script> 
<script src="javascripts/form-validation.js" ></script> 
<script src="javascripts/image-blur-effect.js" ></script> 
<script src="javascripts/parallax-init.js"></script>
<script src="javascripts/mobile-resets.js" ></script> 
<script src="javascripts/animations-init.js"></script>
<script src="javascripts/main.js" ></script> 



</body>
</html>